package br.com.softwar.jogaaonde

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
