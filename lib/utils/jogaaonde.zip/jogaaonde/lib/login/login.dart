
class Login {
  String login;
  String senha;
  String token;

  bool status;
  String msg;

  Login.fromJson(Map<String, dynamic> json) {
    token = json['token'];
  }


  toMap(){
    return {
      "login": login,
      "senha": senha,
      "token": token
    };
  }
}